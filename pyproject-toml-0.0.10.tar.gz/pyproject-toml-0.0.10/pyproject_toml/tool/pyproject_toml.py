__schema__ = {
    "type": "object",
    "properties": {
        "packages": {
            "$ref": "http://json-schema.org/draft-07/schema#/definitions/stringArray",
        }
    },
}
