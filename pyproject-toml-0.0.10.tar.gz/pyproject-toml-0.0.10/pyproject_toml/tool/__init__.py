from . import pyproject_toml

__schema__ = {
    "type": "object",
    "properties": {"pyproject-toml": pyproject_toml.__schema__},
}
